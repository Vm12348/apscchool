setTimeout(() => {
  const banner = document.getElementById("popupBanner");
  if (banner) banner.style.display = "none";
}, 8000); // hides after 8 seconds


// Admission Form
document.getElementById('admissionForm').addEventListener('submit', function (e) {
  e.preventDefault();
  alert('Thank you! Your admission form has been submitted.');
  this.reset();
});

// Contact Form
document.getElementById('contactForm').addEventListener('submit', function (e) {
  e.preventDefault();
  alert('Thank you for contacting us. We will get back to you soon.');
  this.reset();
});
